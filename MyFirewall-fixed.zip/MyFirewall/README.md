# My Firewall

Blocks internet for selected apps using a local VPN (no root). Open this folder in Android Studio,
let Gradle sync, then Run. Android Studio downloads Gradle 8.7 automatically from
gradle/wrapper/gradle-wrapper.properties. For command-line builds run `gradle wrapper` once.

Tip: Settings > Network > VPN > My Firewall > enable "Always-on VPN" and
"Block connections without VPN" so blocked apps stay offline even if the service is killed.
