package com.example.myfirewall

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService

/** ফোন রিবুট বা অ্যাপ আপডেটের পর ফায়ারওয়াল আবার চালু করে (VPN অনুমতি আগে দেওয়া থাকলে)। */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (!Prefs.isEnabled(context)) return
        if (VpnService.prepare(context) != null) return // অনুমতি নেই, ইউজারকে অ্যাপ খুলতে হবে
        try {
            context.startService(Intent(context, FirewallService::class.java))
        } catch (_: Exception) {
        }
    }
}
