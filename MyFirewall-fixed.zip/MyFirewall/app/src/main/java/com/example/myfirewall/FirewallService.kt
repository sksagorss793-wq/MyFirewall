package com.example.myfirewall

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor

/**
 * ব্লক করা অ্যাপগুলোর সব ট্রাফিক একটি ভার্চুয়াল VPN-এ পাঠানো হয়,
 * কিন্তু সেখান থেকে কোথাও ফরোয়ার্ড করা হয় না। ফলে ওই অ্যাপের ইন্টারনেট বন্ধ থাকে।
 * বাকি অ্যাপ স্বাভাবিকভাবে চলে।
 */
class FirewallService : VpnService() {
    private var tun: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP || !Prefs.isEnabled(this)) {
            stopFirewall()
            return START_NOT_STICKY
        }
        startFirewall()
        return if (tun != null) START_STICKY else START_NOT_STICKY
    }

    private fun startFirewall() {
        val blocked = Prefs.getBlocked(this)

        val builder = Builder()
            .setSession("My Firewall")
            .addAddress("10.0.0.2", 32)
            .addAddress("fd00::2", 128)
            .addRoute("0.0.0.0", 0)
            .addRoute("::", 0)

        // গুরুত্বপূর্ণ: একটিও অ্যাপ যোগ না হলে VPN সব অ্যাপের ট্রাফিক ধরে ফেলত।
        // তাই কতগুলো সফলভাবে যোগ হলো গুনে দেখি।
        val valid = mutableSetOf<String>()
        for (pkg in blocked) {
            try {
                builder.addAllowedApplication(pkg)
                valid.add(pkg)
            } catch (_: Exception) {
                // অ্যাপটি আনইনস্টল হয়ে গেছে
            }
        }
        if (valid.size != blocked.size) Prefs.setBlocked(this, valid)
        if (valid.isEmpty()) {
            Prefs.setEnabled(this, false)
            stopFirewall()
            return
        }

        val newTun = try {
            builder.establish()
        } catch (_: Exception) {
            null
        }
        if (newTun == null) {
            // VPN অনুমতি তুলে নেওয়া হয়েছে বা অন্য VPN চালু হয়েছে
            Prefs.setEnabled(this, false)
            stopFirewall()
            return
        }

        // আগে নতুন ইন্টারফেস চালু, তারপর পুরনোটা বন্ধ: মাঝখানে কোনো ফাঁক থাকে না
        val old = tun
        tun = newTun
        old?.close()
        Prefs.setRunning(this, true)
    }

    private fun stopFirewall() {
        tun?.close()
        tun = null
        Prefs.setRunning(this, false)
        stopSelf()
    }

    override fun onRevoke() {
        Prefs.setEnabled(this, false)
        stopFirewall()
    }

    override fun onDestroy() {
        tun?.close()
        tun = null
        Prefs.setRunning(this, false)
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.example.myfirewall.STOP"
    }
}
