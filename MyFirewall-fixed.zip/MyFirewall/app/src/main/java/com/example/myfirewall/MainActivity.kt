package com.example.myfirewall

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.net.VpnService
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private class AppItem(val pkg: String, val label: String, val icon: Drawable)

    private val all = mutableListOf<AppItem>()
    private val shown = mutableListOf<AppItem>()
    private val blocked = mutableSetOf<String>()

    private lateinit var status: TextView
    private lateinit var toggle: Button
    private lateinit var search: EditText
    private lateinit var progress: ProgressBar
    private lateinit var adapter: AppAdapter

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        runOnUiThread { refresh() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        blocked.addAll(Prefs.getBlocked(this))

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(8))
        }
        val hint = TextView(this).apply { setText(R.string.hint) }
        status = TextView(this).apply {
            textSize = 18f
            setPadding(0, dp(8), 0, dp(4))
        }
        toggle = Button(this).apply { setOnClickListener { onToggle() } }
        val vpnSettings = Button(this).apply {
            setText(R.string.vpn_settings)
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_VPN_SETTINGS))
                } catch (_: Exception) {
                }
            }
        }
        search = EditText(this).apply {
            setHint(R.string.search_hint)
            setSingleLine(true)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) = applyFilter()
            })
        }
        progress = ProgressBar(this).apply { isIndeterminate = true }
        adapter = AppAdapter()
        val list = ListView(this).apply {
            this.adapter = this@MainActivity.adapter
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            setOnItemClickListener { _, _, pos, _ -> onAppClicked(shown[pos]) }
        }

        root.addView(hint)
        root.addView(status)
        root.addView(toggle)
        root.addView(vpnSettings)
        root.addView(search)
        root.addView(progress)
        root.addView(list)
        setContentView(root)

        loadApps()
    }

    /** অ্যাপের তালিকা ও আইকন লোড করা ভারী কাজ, তাই ব্যাকগ্রাউন্ড থ্রেডে করা হয়। */
    private fun loadApps() {
        thread {
            val pm = packageManager
            val items = pm.getInstalledApplications(0)
                .filter { it.packageName != packageName && pm.getLaunchIntentForPackage(it.packageName) != null }
                .map { AppItem(it.packageName, pm.getApplicationLabel(it).toString(), it.loadIcon(pm)) }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                all.clear()
                all.addAll(items)
                progress.visibility = View.GONE
                applyFilter()
            }
        }
    }

    private fun applyFilter() {
        val q = search.text.toString().trim().lowercase()
        shown.clear()
        shown.addAll(all.filter { q.isEmpty() || it.label.lowercase().contains(q) })
        adapter.notifyDataSetChanged()
    }

    private fun onAppClicked(item: AppItem) {
        if (!blocked.add(item.pkg)) blocked.remove(item.pkg)
        Prefs.setBlocked(this, blocked)
        adapter.notifyDataSetChanged()
        // তালিকা বদলালে চালু ফায়ারওয়াল নতুন তালিকা দিয়ে আবার সাজানো হয়
        if (Prefs.isEnabled(this)) startService(Intent(this, FirewallService::class.java))
    }

    override fun onResume() {
        super.onResume()
        Prefs.register(this, prefListener)
        refresh()
    }

    override fun onPause() {
        Prefs.unregister(this, prefListener)
        super.onPause()
    }

    private fun refresh() {
        val running = Prefs.isRunning(this)
        status.setText(if (running) R.string.status_on else R.string.status_off)
        status.setTextColor(if (running) Color.parseColor("#2E7D32") else Color.parseColor("#757575"))
        toggle.setText(if (Prefs.isEnabled(this)) R.string.stop else R.string.start)
    }

    private fun onToggle() {
        if (Prefs.isEnabled(this)) {
            Prefs.setEnabled(this, false)
            stopService(Intent(this, FirewallService::class.java))
            refresh()
        } else {
            if (blocked.isEmpty()) {
                Toast.makeText(this, R.string.pick_one, Toast.LENGTH_SHORT).show()
                return
            }
            val i = VpnService.prepare(this)
            if (i != null) startActivityForResult(i, REQ_VPN) else start()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQ_VPN && resultCode == RESULT_OK) start()
    }

    private fun start() {
        Prefs.setEnabled(this, true)
        try {
            startService(Intent(this, FirewallService::class.java))
        } catch (_: Exception) {
            Prefs.setEnabled(this, false)
            Toast.makeText(this, R.string.start_failed, Toast.LENGTH_SHORT).show()
        }
        refresh()
    }

    private inner class AppAdapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int) = shown[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = convertView as? LinearLayout ?: makeRow()
            val item = shown[position]
            (row.getChildAt(0) as ImageView).setImageDrawable(item.icon)
            (row.getChildAt(1) as TextView).text = item.label
            (row.getChildAt(2) as CheckBox).isChecked = item.pkg in blocked
            return row
        }

        private fun makeRow(): LinearLayout = LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
            addView(ImageView(context), LinearLayout.LayoutParams(dp(40), dp(40)))
            addView(TextView(context).apply {
                textSize = 16f
                setPadding(dp(12), 0, dp(12), 0)
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(CheckBox(context).apply {
                isClickable = false
                isFocusable = false
            })
        }
    }

    companion object {
        private const val REQ_VPN = 1
    }
}
