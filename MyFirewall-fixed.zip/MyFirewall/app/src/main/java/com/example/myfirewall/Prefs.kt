package com.example.myfirewall

import android.content.Context
import android.content.SharedPreferences

/**
 * enabled = ব্যবহারকারী ফায়ারওয়াল চালু রাখতে চায় (রিবুটের পরও মনে থাকে)
 * running = VPN সত্যিই এই মুহূর্তে চালু আছে
 */
object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("fw", Context.MODE_PRIVATE)

    fun getBlocked(c: Context): Set<String> =
        HashSet(p(c).getStringSet("blocked", emptySet()) ?: emptySet())

    fun setBlocked(c: Context, s: Set<String>) =
        p(c).edit().putStringSet("blocked", HashSet(s)).apply()

    fun isEnabled(c: Context) = p(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("enabled", v).apply()

    fun isRunning(c: Context) = p(c).getBoolean("running", false)
    fun setRunning(c: Context, v: Boolean) = p(c).edit().putBoolean("running", v).apply()

    fun register(c: Context, l: SharedPreferences.OnSharedPreferenceChangeListener) =
        p(c).registerOnSharedPreferenceChangeListener(l)

    fun unregister(c: Context, l: SharedPreferences.OnSharedPreferenceChangeListener) =
        p(c).unregisterOnSharedPreferenceChangeListener(l)
}
